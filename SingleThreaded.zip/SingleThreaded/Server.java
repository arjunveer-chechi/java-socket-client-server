package SingleThreaded;

import java.io.*;
import java.net.*;

public class Server {

    public void run() {

        int port = 8010;

        try {
            ServerSocket socket = new ServerSocket(port);
            socket.setSoTimeout(100000);

            while (true) {
                try {
                    System.out.println("Server is listening on port " + port);
                    Socket acceptedConnection = socket.accept();
                    System.out.println("Connection accepted from client "+ acceptedConnection.getRemoteSocketAddress());
                    PrintWriter toClient = new PrintWriter(acceptedConnection.getOutputStream(),true);
                    toClient.println("Hello from the Server");
                    BufferedReader fromClient = new BufferedReader(new InputStreamReader(acceptedConnection.getInputStream()));
                    String line = fromClient.readLine();
                    System.out.println("Message from client: " + line);
                    acceptedConnection.close();

                } catch (SocketTimeoutException e) {
                    // timeout ignored
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Server server = new Server();
        try{
            server.run();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
}